// Example of using Axon with accelerometer

#define RPRINTF_FLOAT

#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "servos.h"
#include "hardware.h"

//use for LED display and servo position
uint8_t led_value;
int8_t servo_position;


// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	//initialize hardware PWM for servos
	//servoPWMInit(&bank1);
	//software based PWM
	servosInit(&bank1, TIMER1);

	//initialize sensors
	accelerometerInit(accel);
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	read_sensors();//update sensor values

	//calibration - all sensors are off, so values need to be stretched
	//rotate your accelerometer to find the min and max for each axis at 1g
	//plug in the min and max here:
	accel_X=interpolate(accel_X,-560,480,-1000,1000);
	accel_Y=interpolate(accel_Y,-563,428,-1000,1000);
	accel_Z=interpolate(accel_Z,-497,531,-1000,1000);


	//stretch value for LED display
	led_value=interpolate(accel_X,-1100,1100,0,9);//led is from 0->9
	servo_position=interpolate(accel_X,-1000,1000,-100,100);//servo is from -100->100

	//command led and servo
	led_put_char(led_value);
	act_setSpeed(&servo1, servo_position);

	//output values via USB port
	accelerometerDump(accel);//measured output
	rprintf("\nx=%d y=%d z=%d",accel_X,accel_Y,accel_Z);//true output
	rprintf("\n\n");

	return 100000;
}
