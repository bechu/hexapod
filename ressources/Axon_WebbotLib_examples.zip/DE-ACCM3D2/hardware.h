//define servos, sensors, and other stuff here
//this keeps hardware separate from other code - making it easy to share/port

//declare libraries
#include "Sensors/Acceleration/DimensionEngineering/ACCM3D2.h"


//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)38400
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte


//define servo
SERVO servo1 = MAKE_SERVO(FALSE, A0, 1500, 800);
//create servo list
SERVO_LIST servo_list[] = {&servo1};
//create a driver for the list of servos
SERVO_DRIVER bank1 = MAKE_SERVO_DRIVER(servo_list);


//define IMU variables
ACCEL_TYPE accel_X;
ACCEL_TYPE accel_Y;
ACCEL_TYPE accel_Z;

//declare connected devices
DE_ACCM3D2 accel=MAKE_DE_ACCM3D2(ADC0,ADC1,ADC2);//requires 5V digital pin


//call this function to read all your sensors at once
void read_sensors(void)
	{
	//get values
	accelerometerRead(accel);

	//store values
	accel_X=accel.accelerometer.x_axis_mG;
	accel_Y=accel.accelerometer.y_axis_mG;
	accel_Z=accel.accelerometer.z_axis_mG;
	}
