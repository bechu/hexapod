/*
Use this program to correctly visualize PWM using the SoR Scope

this program is also a good example of setting up a hardware interrupt

interrupt pins can be found using the datasheet http://www.societyofrobots.com/axon2/axon2_datasheet.shtml

written by societyofrobots.com using WebbotLib; February 2010
*/


//#define WIRELESS//if you want to use bluetooth and not USB, uncomment this line
#define USB//if you want to use bluetooth and not USB, uncomment this line


//WebbotLib includes
//#include "sys/axon.h"
#include "sys/axon2.h"
#include "rprintf.h"
#include "servos.h"
#include "pinChange.h"


//make uart names more sane
#define USB_UART UART1
#define WIRELESS_UART UART2
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define USB_BAUD (BAUD_RATE)115200//use 230400 to read sub-1ms signals (such as for servos)
#define WIRELESS_BAUD (BAUD_RATE)38400


//servo PWM code (used as an example)
SERVO test_servo = MAKE_SERVO(TRUE, H4, 1500, 500);
SERVO_LIST servos[] = {&test_servo};
SERVO_DRIVER servo_bank = MAKE_SERVO_DRIVER(servos);


//pin change interrupt
void myCallback(const IOPin* io,boolean val, volatile void* data)
	{
	if(val==true)
		rprintf("0\n255\n");//rising square wave
	else
		rprintf("255\n0\n");//falling square wave
	}


//initiate hardware
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);
	uartInit(WIRELESS_UART, WIRELESS_BAUD);

	// Set which uart is default during startup
	#ifdef USB
		rprintfInit(USB_ACTIVATE);
	#endif
	#ifdef WIRELESS
		rprintfInit(WIRELESS_ACTIVATE);
	#endif

	//rprintf("\nAxon initiated.\n");

	//initialize servo PWM
	servoPWMInit(&servo_bank);
	act_setSpeed(&test_servo, 40);

	//when B4 changes, call an interrupt
	pin_change_attach(B4, &myCallback, null);
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	return 0;
}


// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){
	
	//keep looping, interrupt driven, only display most recent change

	return 0;
}

