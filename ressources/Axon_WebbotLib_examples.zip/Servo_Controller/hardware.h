/****************************************************************************
*
*   Copyright (c) 2009 www.societyofrobots.com
*   (please link back if you use this code!)
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License version 2 as
*   published by the Free Software Foundation.
*
*   Alternatively, this software may be distributed under the terms of BSD
*   license.
*
****************************************************************************/



/*
PWM pins available:
8-bit timer pins: G5 (T0), H6/B4 (T2) 
16-bit timer pins: B5/B6/B7 (T1), E3/E4/E5 (T3), H3/H4/H5 (T4), L3/L4/L5 (T5)
*/

//define actuators, use TRUE for right side, FALSE for inverted side
//if you use hardware PWM, use only PWM pins
//MAKE_SERVO(ROTATION DIRECTION, PIN, CENTER, RANGE)
SERVO arm_left_base = MAKE_SERVO(TRUE, E7, 1610, 1000);
SERVO arm_left_J1 = MAKE_SERVO(TRUE, B5, 1500, 1000);
SERVO arm_left_J2 = MAKE_SERVO(TRUE, E3, 1300, 1100);
SERVO arm_left_claw = MAKE_SERVO(TRUE, E5, 1600, 500);

SERVO arm_right_base = MAKE_SERVO(TRUE, H5, 1360, 1000);
SERVO arm_right_J1 = MAKE_SERVO(FALSE, B7, 1680, 1000);
SERVO arm_right_J2 = MAKE_SERVO(FALSE, L6, 1800, 1100);
SERVO arm_right_claw = MAKE_SERVO(FALSE, L7, 1450, 500);

SERVO wheel_left = MAKE_SERVO(TRUE, H6, 1545, 500);
SERVO wheel_right = MAKE_SERVO(FALSE, L0, 1550, 500);

SERVO camera_hor = MAKE_SERVO(TRUE, G3, 1500, 1000);
SERVO camera_ver = MAKE_SERVO(TRUE, L2, 1700, 700);


// create actuator list
//SERVO_LIST servos_PWM[] = {&knee_left,&knee_right, &hip_left,&hip_right};
SERVO_LIST servos[] = {&arm_left_base, &arm_left_J1, &arm_left_J2, &arm_left_claw, &arm_right_base, &arm_right_J1, &arm_right_J2, &arm_right_claw, &wheel_left, &wheel_right, &camera_hor, &camera_ver};

// Create a driver for the list of servos
//SERVO_DRIVER bank1 = MAKE_SERVO_DRIVER(servos_PWM);
SERVO_DRIVER bank2 = MAKE_SERVO_DRIVER(servos);





//turning off servos improves efficiency and stops servo jumping
void turn_actuators_OFF(void)
	{
	//servosDisconnect(&bank1);
	servosDisconnect(&bank2);
	//act_SetConnected(&driver, FALSE);
	}

void turn_actuators_ON(void)
	{
	//servosConnect(&bank1);
	servosConnect(&bank2);
	//act_SetConnected(&driver, TRUE);
	}
