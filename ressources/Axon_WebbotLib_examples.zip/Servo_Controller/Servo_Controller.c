//attempt at using the Axon and Axon II as a servo controller


//define how data should be sent (choose only one)
//#define U0
#define USB

//declare microcontroller
//#define AXON
#define AXON2



//WebbotLib Includes
#ifdef AXON
	#include "sys/axon.h"
#endif
#ifdef AXON2
	#include "sys/axon2.h"
#endif

#include "buffer.h"
#include "servos.h"		//use for servos
#include "rprintf.h"	//use for UART


//UART defines (name your UART)
#define U0_UART UART0
#define USB_UART UART1
//UART baud defines (change baud rate)
#define U0_BAUD (BAUD_RATE)230400
#define USB_BAUD (BAUD_RATE)230400
//UART define which uart to use
#define U0_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
//getting data
#define GET_DATA_U0 uart0GetByte()
#define GET_DATA_USB uart1GetByte()


//create a big buffer for UART
#ifdef U0
	#define UART0_RX_BUFFER_SIZE 100
#endif
#ifdef USB
	#define UART1_RX_BUFFER_SIZE 100
#endif


int cByte=-1;			//store last recieved character
int buff_array[100];	//store last command
uint8_t buff_pos=0;		//record current position in array
uint8_t buff_read=0;	//record current position in array
boolean command_received=0;	//active last command


#include "hardware.h"	//declare your servo and sensor ports here


//initialize hardware, ie servos, UART, etc.
void appInitHardware(void)
	{
	servosInit(&bank2, TIMER3);//software based PWM

	turn_actuators_OFF();//keep actuators off until everything is initiated

	#ifdef AXON2
		led_off();
	#endif
		
	//setup UART0 or USB
	#ifdef USB
		uartInit(USB_UART, USB_BAUD);
		rprintfInit(USB_ACTIVATE);
	#endif
	#ifdef U0
		uartInit(U0_UART, U0_BAUD);//bluetooth
		rprintfInit(U0_ACTIVATE);
	#endif
	}


TICK_COUNT appInitSoftware(TICK_COUNT loopStart)
	{
	rprintf("init\n");
	
	return 0;
	}

	
// This is the main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart)
	{
	////////////GET COMMAND/////////////
	#ifdef USB
		cByte=GET_DATA_USB;
	#endif
	#ifdef U0
		cByte=GET_DATA_U0;
	#endif

	












	//fill up array with command recieved from UART
	if(cByte!=-1)//has new data
		{
		buff_array[buff_pos]=cByte;
		buff_pos++;

		if(cByte == 'r')//if command is finished
			command_received=1;
		}

	//when command is recieved, act upon it
	if(command_received)
		{
		buff_read=0;

		//while the full array hasn't been read yet
		while(buff_read<=buff_pos)
			{
			buff_array[buff_read];
			buff_array[buff_read];

			act_setSpeed(&servo, buff_array[buff_read]);			

			buff_read++;
			}

	turn_actuators_ON(); //activate servos

	
		buff_pos=0;//reset array
		}


	if(cByte!=-1)//has new data
		{
		port_letter=cByte;

	act_setSpeed(&servo, position);
		}


	return 0;
	}
