//define servos, sensors, and other stuff here
//this keeps hardware separate from other code - making it easy to share/port

//declare libraries
#include "Sensors/Distance/Devantech/SRF05_Sonar.h"
#include "Sensors/Distance/Devantech/SRF04_Sonar.h"
#include "Sensors/Distance/Maxbotix/EZ1.h"
#include "Sensors/Distance/Ping/PingSonar.h"
#include "Sensors/Distance/Sharp/GP2.h"

//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)38400
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte


//declare connected devices

#ifdef SONAR
//Devantech_SRF05 sonar = MAKE_Devantech_SRF05(A1);//requires 5V digital pin
Devantech_SRF04 sonar = MAKE_Devantech_SRF04(A0,A2);//requires 5V digital pin (trigger,output)(5V, output, trigger, NC, ground)
//MaxSonarEZ1 sensor=MAKE_MaxSonarEZ1(A1);
//PingSonar sensor=MAKE_PingSonar(A1);
#endif
#ifdef SHARP
Sharp_GP2D12 sharp = MAKE_Sharp_GP2D12(K4);//requires 5V analog pin
#endif
