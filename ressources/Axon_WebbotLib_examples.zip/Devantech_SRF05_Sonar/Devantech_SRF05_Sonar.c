// Example of using Axon for sonar and sharp IR

//uncomment the sensor you want to use
#define SONAR
//#define SHARP

#define RPRINTF_FLOAT

#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "hardware.h"

DISTANCE_TYPE dist_sonar;
DISTANCE_TYPE dist_sharp;
DISTANCE_TYPE dist;

//change this variable to scale the result
uint16_t scale=2;

// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	//initialize sensor
	#ifdef SONAR
		distanceInit(sonar);
	#endif
	#ifdef SHARP
		distanceInit(sharp);
	#endif

	//declare digital output pins
	pin_make_output(G5);
	pin_make_output(E3);
	pin_make_output(E4);
	pin_make_output(E5);
	pin_make_output(E6);
	pin_make_output(E7);
	pin_make_output(H3);
	pin_make_output(H4);
	pin_make_output(H5);
	pin_make_output(H6);
	pin_make_output(B4);
	pin_make_output(B5);
	pin_make_output(B6);
	pin_make_output(B7);

}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){


	#ifdef SONAR
		distanceRead(sonar);//update sonar value
	#endif
	#ifdef SHARP
		distanceRead(sharp);//update sharp value
	#endif

	
	#ifdef SONAR
		dist_sonar=sonar.distance.cm;//store sonar value
	#endif
	#ifdef SHARP
		dist_sharp=sharp.distance.cm;//store sharp value
	#endif


	
	#ifdef SONAR
		rprintf("\n sonar: ");//go to next line
		distanceDump(sonar);//output value
	#endif
	#ifdef SHARP
		rprintf("\n sharp: ");//go to next line
		distanceDump(sharp);//output value
	#endif


	#ifdef SONAR
		dist=dist_sonar;//set distance to sonar
	#endif
	#ifdef SHARP
		dist=dist_sharp;//set distance to sharp IR
	#endif
	


	//turn all pins off here
	pin_low(G5);
	pin_low(E3);
	pin_low(E4);
	pin_low(E5);
	pin_low(E6);
	pin_low(E7);
	pin_low(H3);
	pin_low(H4);
	pin_low(H5);
	pin_low(H6);
	pin_low(B4);
	pin_low(B5);
	pin_low(B6);
	pin_low(B7);


	//turn on selective pins
	if(dist>scale*5)
		pin_high(G5);
	if(dist>scale*6)
		pin_high(E3);
	if(dist>scale*7)
		pin_high(E4);
	if(dist>scale*8)
		pin_high(E5);
	if(dist>scale*9)
		pin_high(E6);
	if(dist>scale*10)
		pin_high(E7);
	if(dist>scale*11)
		pin_high(H3);
	if(dist>scale*12)
		pin_high(H4);
	if(dist>scale*13)
		pin_high(H5);
	if(dist>scale*14)
		pin_high(H6);
	if(dist>scale*15)
		pin_high(B4);
	if(dist>scale*16)
		pin_high(B5);
	if(dist>scale*17)
		pin_high(B6);
	if(dist>scale*18)
		pin_high(B7);


	return 50000;//add delay
}
