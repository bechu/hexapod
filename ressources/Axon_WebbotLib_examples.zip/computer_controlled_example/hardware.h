/*************************************************************************
Authored by John Palmisano of SocietyofRobots.com
in collaboration with Clive Webster of WebbotLib

2009

intended use for Axon and Axon II

instructions:
This file is where you define all of your intended hardware connected to
your Axon microcontroller. You can set up baud rates for your UART,
specificy which sensors you are using, declare servos, etc.

Keeping this separate from your other code makes code sharing easy.
*************************************************************************/



//////////////////////////LIBRARIES///////////////////////////
//declare sensor libraries (examples are commented out)
//#include <Sensors/Acceleration/DynamicEngineering/ACCM3D2.h>
//#include <Sensors/Compass/Honeywell/HMC6343.h>
//#include <Sensors/Gyro/InvenSense/IDG300.h>
//////////////////////////////////////////////////////////////


/////////////////////////////UART/////////////////////////////
//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)38400
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte

#define USB_GET uart1GetByte()
//////////////////////////////////////////////////////////////


/////////////////////////////SENSORS//////////////////////////
// define custom sensors
#define read_sensor_1 a2dConvert8bit(ADC_NUMBER_TO_CHANNEL(0))
#define read_sensor_2 a2dConvert8bit(ADC_NUMBER_TO_CHANNEL(1))

//sensor defines  (examples are commented out)
//GYRO_TYPE gyro_X;
//GYRO_TYPE gyro_Y;
//ACCEL_TYPE accel_X;
//ACCEL_TYPE accel_Y;
//ACCEL_TYPE accel_Z;
//COMPASS_TYPE compass;
//COMPASS_TYPE pitchCompass;
//COMPASS_TYPE rollCompass;

//declare sensor pins (examples are commented out)
//DE_ACCM3D2 accm3d2 = MAKE_DE_ACCM3D2(F5,F6,F7);//accelerometer
//HMC6343	hmc6343 = MAKE_HMC6343();//compass goes to I2C
//IDG300 idg300 = MAKE_IDG300(F0, F1);//gyro



/////////////////////////////SERVOS///////////////////////////
//define servo hardware, use TRUE for right side, FALSE for inverted side
//if you use hardware PWM, use only PWM pins
//example: MAKE_SERVO(ROTATION DIRECTION, PIN, CENTER, RANGE)
SERVO servo_1 = MAKE_SERVO(FALSE, E7, 1500, 500);
SERVO servo_2 = MAKE_SERVO(FALSE, H3, 1500, 500);
SERVO servo_3 = MAKE_SERVO(FALSE, H5, 1500, 500);

//SERVO digital_example = MAKE_SERVO(FALSE, H5, 1520, 910);//digital servos have greater range

// Create the list - remember to place an & at the
// start of each servo name
SERVO_LIST servos[] = {&servo_1,&servo_2,&servo_3};

// Create a driver for the list of servos
SERVO_DRIVER bank1 = MAKE_SERVO_DRIVER(servos);
//////////////////////////////////////////////////////////////

