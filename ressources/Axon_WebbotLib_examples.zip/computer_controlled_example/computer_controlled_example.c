/*************************************************************************
AXON AND AXON II CODE FOR WEBBOTLIB

Authored by John Palmisano of SocietyofRobots.com
in collaboration with Clive Webster of WebbotLib.

For more information, see:
http://www.societyofrobots.com/axon
http://www.societyofrobots.com/axon2
http://sourceforge.net/projects/webbotavrclib

2009

intended use for Axon and Axon II

instructions:
Read comments for explanation of all code.

appInitHardware() is for initiating the Axon.

appControl() is where your code goes. It is similar to control.c
for the original Axon code.

See hardware.h for defining your external hardware.
See sys/axon2.h in WebbotLib to change which pins are input and output.
*************************************************************************/


//allows for printing with features, but uses more memory
#define RPRINTF_FLOAT
#define RPRINTF_COMPLEX

//additional math capabilities
//#include <math.h>

//WebbotLib includes
#include "sys/axon.h"	//defines your MCU (change to axon.h if you use the original Axon)
#include "servos.h"		//use for software servo PWM
#include "a2d.h"		//use for ADC
#include "rprintf.h"	//use for UART
//#include "i2c_master.h"	//use for I2C
//#include "buffer.h"	//use for GPS and other serial stuff

//user includes
#include "hardware.h"


// In my initialising code - pass the list of servos to control
void appInitHardware(void)
	{
	//initialize UART ports (see hardware.h to change baud/names)
	uartInit(GPS_UART, GPS_BAUD);			//UART0
	uartInit(USB_UART, USB_BAUD);			//USB
	uartInit(WIRELESS_UART, WIRELESS_BAUD);	//UART2
	uartInit(OTHER_UART, OTHER_BAUD);		//UART3

	// declare USB for output
	rprintfInit(USB_ACTIVATE);

	// Initialise the servo controller
	//servoPWMInit(&bank1);					//use PWM to control servos (must use PWM pins!)
	servosInit(&bank1, TIMER1);	//use software PWM to control servos (can use any pin)

	// Initiate Sensors (examples commented out)
	//accelerometerInit(accm3d2);
	//compassInit(hmc6343);
	//gyroInit(idg300);

	}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon Initiated.\n\n");
return 0;
}


int tempbyte;

// This is the main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart)
	{
	tempbyte=USB_GET;//get a single character


	//power servos
	if (tempbyte=='1')
		servosDisconnect(&bank1);//turn servos off
	else if (tempbyte=='2')
		servosConnect(&bank1);//turn servos on


	//move some servos around	
	if (tempbyte=='3')
		act_setSpeed(&servo_1,0);
	if (tempbyte=='4')
		act_setSpeed(&servo_2,50);
	if (tempbyte=='5')
		act_setSpeed(&servo_3,-50);
	if (tempbyte=='6')
		act_setSpeed(&servo_3,90);


	//print out sensor data	
	if (tempbyte=='6')
		rprintf("%d", read_sensor_1);
	if (tempbyte=='7')
		rprintf("%d", read_sensor_2);


	return 2000; // wait for 20ms to stop crazy oscillations (long story)
	}
