//////////////////////////LIBRARIES///////////////////////////
//declare sensor libraries (examples are commented out)
#include "Motors/DimensionEngineering/Sabertooth.h"
//use this to set dip switches: http://dimensionengineering.com/datasheets/Sabertoothdipwizard/start.htm
//http://dimensionengineering.com/datasheets/Sabertoothdipwizard/nonlithium/serial/simple/single.htm
//////////////////////////////////////////////////////////////


/////////////////////////////UART/////////////////////////////
//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)115200
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte


#define USB_GET uart1GetByte()
#define WIRELESS_GET uart2GetByte()
//////////////////////////////////////////////////////////////

//define motors
SABERTOOTH_MOTOR left=MAKE_SABERTOOTH_MOTOR(TRUE,128,1);
SABERTOOTH_MOTOR right=MAKE_SABERTOOTH_MOTOR(TRUE,128,2);

//group motors
SABERTOOTH_MOTOR_LIST motors[]={&left,&right};

//Createa driver for the list of motors
SABERTOOTH_DRIVER driver=MAKE_SABERTOOTH_DRIVER(motors,UART0,38400,SIMPLE);

