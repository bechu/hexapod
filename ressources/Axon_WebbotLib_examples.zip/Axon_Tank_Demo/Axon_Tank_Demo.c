//Example of using Axon with serial motor driver and wireless control

//#define USB_controlled
#define BLUETOOTH_controlled

//allows for printing with features, but uses more memory
#define RPRINTF_FLOAT
#define RPRINTF_COMPLEX

//additional math capabilities
//#include <math.h>

//WebbotLib includes
#include "sys/axon2.h"	//defines your MCU (change to axon.h if you use the original Axon)
//#include "servos.h"		//use for software servo PWM
//#include "a2d.h"		//use for ADC
#include "rprintf.h"	//use for UART

//user includes
#include "hardware.h"


// In my initialising code - pass the list of servos to control
void appInitHardware(void)
	{
	//initialize UART ports (see hardware.h to change baud/names)
	uartInit(GPS_UART, GPS_BAUD);			//UART0
	uartInit(USB_UART, USB_BAUD);			//USB
	uartInit(WIRELESS_UART, WIRELESS_BAUD);	//UART2
	uartInit(OTHER_UART, OTHER_BAUD);		//UART3

	// declare USB for output
	#ifdef USB_controlled
		rprintfInit(USB_ACTIVATE);
	#endif
	#ifdef BLUETOOTH_controlled
		rprintfInit(WIRELESS_ACTIVATE);
	#endif

	//Initialise motor controller
	sabertoothInit(&driver);

	led_off();//clear display
	}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon Initiated.\n\n");
return 0;
}

int tempbyte;

//vehicle speed
DRIVE_SPEED speed=30;
//note: left and right need to be high - high friction turning on carpets
DRIVE_SPEED turn=80;

//define directions
void go_left(void)
	{
	act_setSpeed(&left,-turn);
	act_setSpeed(&right,turn);
	led_off();
	segled_on(&led_display, SEGMENT_F);
	segled_on(&led_display, SEGMENT_E);
	}
void go_right(void)
	{
	act_setSpeed(&left,turn);
	act_setSpeed(&right,-turn);
	led_off();
	segled_on(&led_display, SEGMENT_B);
	segled_on(&led_display, SEGMENT_C);
	}
void go_straight(void)
	{
	act_setSpeed(&left,speed);
	act_setSpeed(&right,speed);
	led_off();
	segled_on(&led_display, SEGMENT_A);
	}
void go_reverse(void)
	{
	act_setSpeed(&left,-speed);
	act_setSpeed(&right,-speed);
	led_off();
	segled_on(&led_display, SEGMENT_D);
	}
void stop_stupid_robot(void)
	{
	act_setSpeed(&left,0);
	act_setSpeed(&right,0);
	led_off();
	segled_on(&led_display, SEGMENT_G);
	}


// This is the main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart)
	{
	#ifdef USB_controlled
		tempbyte=USB_GET;//get a single character
	#endif
	#ifdef BLUETOOTH_controlled
		tempbyte=WIRELESS_GET;
	#endif
	
	//control direction
	if (tempbyte=='a')
		go_left();
	else if (tempbyte=='d')
		go_right();
	else if (tempbyte=='w')
		go_straight();
	else if (tempbyte=='x')
		go_reverse();
	else if (tempbyte=='s')
		stop_stupid_robot();

	//control speed by < and >
	if (tempbyte==',')
		{
		speed-=10;
		if (speed < 0)
			speed=0;
		rprintf("\nspeed=%d ",speed);
		}
	if (tempbyte=='.')
		{
		speed+=10;
		if (speed > 100)
			speed=100;
		rprintf("\nspeed=%d ",speed);
		}

	return 2000; // wait for 2ms
	}
