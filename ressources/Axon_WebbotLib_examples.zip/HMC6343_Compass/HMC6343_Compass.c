// Example of converting Axon to USB to Serial Adapter

#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "i2c_master.h"	//use for I2C
#include "hardware.h"

// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	//initialize compass
	compassInit(my_compass);
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	
	rprintf("Compass=%d\n",bearing);
	compassDump(my_compass);
	rprintf("\n");

	return 200000;
}
