//define servos, sensors, and other stuff here
//this keeps hardware separate from other code - making it easy to share/port

//declare libraries
#include "Sensors/Compass/Honeywell/HMC6343.h"


//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)38400
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte


//define variables
COMPASS_TYPE bearing;
COMPASS_TYPE roll;
COMPASS_TYPE pitch;


//declare connected devices
HMC6343 my_compass=MAKE_HMC6343();//requires I2C and 3V power


//use this function to update sensor values
void read_sensors(void)
	{
	compassRead(my_compass);//update compass value

	//store values
	bearing=my_compass.compass.bearingDegrees;
	roll=my_compass.compass.rollDegrees;
	pitch=my_compass.compass.pitchDegrees;
	}
