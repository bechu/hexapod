//the actual program - reads pins and outputs data

void ADC_1(void)
	{
	//gather data
	a0=a2dConvert8bit(ADC0);

	//report data
	rprintf("%d",a0);
	}

void ADC_3(void)
	{
	//gather data
	a0=a2dConvert8bit(ADC0);
	a1=a2dConvert8bit(ADC1);
	a2=a2dConvert8bit(ADC2);

	//report data
	rprintf("%d %d %d",a0,a1,a2);
	}

void ADC_8(void)
	{
	//gather data
	a0=a2dConvert8bit(ADC0);
	a1=a2dConvert8bit(ADC1);
	a2=a2dConvert8bit(ADC2);
	a3=a2dConvert8bit(ADC3);
	a4=a2dConvert8bit(ADC4);
	a5=a2dConvert8bit(ADC5);
	a6=a2dConvert8bit(ADC6);
	a7=a2dConvert8bit(ADC7);

	//report data
	rprintf("%d %d %d %d %d %d %d %d",a0,a1,a2,a3,a4,a5,a6,a7);
	}

void ADC_16(void)
	{
	//gather data
	a0=a2dConvert8bit(ADC0);
	a1=a2dConvert8bit(ADC1);
	a2=a2dConvert8bit(ADC2);
	a3=a2dConvert8bit(ADC3);
	a4=a2dConvert8bit(ADC4);
	a5=a2dConvert8bit(ADC5);
	a6=a2dConvert8bit(ADC6);
	a7=a2dConvert8bit(ADC7);
	a8=a2dConvert8bit(ADC8);
	a9=a2dConvert8bit(ADC9);
	a10=a2dConvert8bit(ADC10);
	a11=a2dConvert8bit(ADC11);
	a12=a2dConvert8bit(ADC12);
	a13=a2dConvert8bit(ADC13);
	a14=a2dConvert8bit(ADC14);
	a15=a2dConvert8bit(ADC15);

	//report data
	rprintf("%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15);
	}
