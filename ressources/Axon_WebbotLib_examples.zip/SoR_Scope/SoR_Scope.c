// Example of converting Axon to USB based oscope
//please credit all code to societyofrobots.com


#define WIRELESS//if you want to use bluetooth and not USB, uncomment this line
//#define USB//if you want to use bluetooth and not USB, uncomment this line
//#define USE_TIMER//if you want to output the timer, uncomment this line



//#include "sys/axon.h"
#include "sys/axon2.h"
#include "rprintf.h"


//make uart names more sane
#define USB_UART UART1
#define WIRELESS_UART UART2
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define USB_BAUD (BAUD_RATE)115200//230400
#define WIRELESS_BAUD (BAUD_RATE)38400//57600//38400


//higher prescales are more accurate, but slower too
//#define ADC_DEFAULT_PRESCALE ADC_PRESCALE_DIV2
//#define ADC_DEFAULT_PRESCALE ADC_PRESCALE_DIV4
//#define ADC_DEFAULT_PRESCALE ADC_PRESCALE_DIV8
//#define ADC_DEFAULT_PRESCALE ADC_PRESCALE_DIV16
#define ADC_DEFAULT_PRESCALE ADC_PRESCALE_DIV32
//#define ADC_DEFAULT_PRESCALE ADC_PRESCALE_DIV64
//#define ADC_DEFAULT_PRESCALE ADC_PRESCALE_DIV128
#include "a2d.h"


uint8_t a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15;


#ifdef USE_TIMER
	TICK_COUNT time_start;
#endif


#include "functions.h"//the program that reads pins and outputs data

// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);
	uartInit(WIRELESS_UART, WIRELESS_BAUD);

	// Set which uart is default during startup
	#ifdef USB
		rprintfInit(USB_ACTIVATE);
	#endif
	#ifdef WIRELESS
		rprintfInit(WIRELESS_ACTIVATE);
	#endif

}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	#ifdef USE_TIMER
		//get start time
		time_start = clockGetus();
	#endif

	rprintf("\nAxon initiated.\n");

	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

while(1);

	//select number of ports to output
	//ADC_1();
	ADC_3();
	//ADC_8();
	//ADC_16();

	#ifdef USE_TIMER
		//add time stamp at end of data:
		rprintf(" %d",clockGetus()-time_start);
		//reset start time
		time_start = clockGetus();
	#endif
	
	rprintf("\r\n");

	return 0;
}

