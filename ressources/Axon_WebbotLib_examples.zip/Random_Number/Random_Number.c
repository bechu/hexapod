
//allows for printing with features, but uses more memory
#define RPRINTF_FLOAT
#define RPRINTF_COMPLEX


//WebbotLib Includes
#include "sys/axon2.h"//declare microcontroller
#include "a2d.h"		//use for ADC
#include "rprintf.h"	//use for UART

//additional math capabilities
//#include <math.h>
#include <stdlib.h>

//user includes
#include "hardware.h"	//declare your servo and sensor ports here
#include "random_number_gen.h" //true random number generator


//output random numbers for fun
void random_examples(void)
	{
	
	rprintf("\n1 digit random #%d",random_number(1));
	rprintf("\n2 digit random #%d",random_number(2));
	rprintf("\n3 digit random #%d",random_number(3));
	rprintf("\n4 digit random #%d",random_number(4));
	rprintf("\n5 digit random #%d",random_number(5));

	delay_ms(2000);//delay 2s
	}

//random number dump to analyze how random it actually is
//plug into excel and graph, silly!
void random_test(void)
	{
	uint16_t rand_number;
	uint16_t zero=0;
	uint16_t one=0;
	uint16_t two=0;
	uint16_t three=0;
	uint16_t four=0;
	uint16_t five=0;
	uint16_t six=0;
	uint16_t seven=0;
	uint16_t eight=0;
	uint16_t nine=0;

	uint16_t counter=0;

	while(counter<6550)
		{
		rand_number=random_number(1);

		if(rand_number==0)
			zero++;
		else if(rand_number==1)
			one++;
		else if(rand_number==2)
			two++;
		else if(rand_number==3)
			three++;
		else if(rand_number==4)
			four++;
		else if(rand_number==5)
			five++;
		else if(rand_number==6)
			six++;
		else if(rand_number==7)
			seven++;
		else if(rand_number==8)
			eight++;
		else if(rand_number==9)
			nine++;

		counter++;
		delay_ms(1);
		}

	rprintf("%d %d %d %d %d %d %d %d %d %d\n",zero,one,two,three,four,five,six,seven,eight,nine);

	while(1);
	}


//initialize hardware, ie servos, UART, etc.
void appInitHardware(void)
	{		
	//setup UART on USB
	uartInit(USB_UART, USB_BAUD);
	rprintfInit(USB_ACTIVATE);

	led_off();
	}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart)
	{
	init_rand_gen();

	rprintf("\nAxon II initiated.\n\n");

	return 0;
	}

// This is the main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart)
	{
	random_examples();
	//random_test();

	return 1; // 2us delay
	}
