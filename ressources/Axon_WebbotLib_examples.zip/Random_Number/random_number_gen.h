/*************************************************************************
AXON AND AXON II RANDOM NUMBER GENERATOR

Authored by John Palmisano of SocietyofRobots.com

For more information, see:
http://www.societyofrobots.com/axon
http://www.societyofrobots.com/axon2

2010

intended use for Axon and Axon II

Make sure you #include <stdlib.h> first.

To use it, #include random_number_gen.h in your main file.

Then in your main, call random_number(num_of_digits);

it returns an unsigned 16 bit random number, given required number of digits, up to 5 digits
*************************************************************************/


//this function reads the ADC to collect electrical noise
//then feeds that value as a seed into a random number generator
//and finally outputs the least sigificant digits,
//depending on required desired number of maximum digits


//call this function to reseed the random number list
void init_rand_gen(void)
		{
		uint16_t seed;

		//read random values on ADC port, sum total
		for(uint8_t i=0;i<NUM_ADC_CHANNELS;i++)
			seed=seed+a2dConvert10bit(ADC_NUMBER_TO_CHANNEL(i));

		//sets random seed to current ADC value
		srandom(seed);
		}

uint16_t random_number(uint8_t digits)
		{
		//returns random number between 0 and 32767
		//look at least significant digits only (divide by 10, take remainder)
		if(digits==1)
			return random()%10;
		if(digits==2)
			return random()%100;
		if(digits==3)
			return random()%1000;
		if(digits==4)
			return random()%10000;
		if(digits==5)
			return abs(random()%100000);

		return 0;
		}
