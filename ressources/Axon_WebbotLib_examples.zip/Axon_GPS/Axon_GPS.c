// Example of how to use an NMEA compatible GPS with Axon

#define RPRINTF_FLOAT

#include "buffer.h"
#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "hardware.h"



// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);
	//uartInit(GPS_UART, GPS_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	// Turn on LED for no signal
	statusLED_on();
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){
	gpsNMEAprocess(&nmea);
	if(nmea.info.valid){
		statusLED_off();
		 rprintf("# sat:%d",nmea.info.numSatellites);
		 rprintf(" long:"); rprintfFloat(10,nmea.info.longitude);
		 rprintf(" lat:"); rprintfFloat(10,nmea.info.latitude);
		 rprintf(" alt:"); rprintfFloat(10,nmea.info.altitude);
		 rprintf(" time:"); rprintfFloat(10,nmea.info.fixTime);
		 rprintf(" speed:"); rprintfFloat(10,nmea.info.speed);
		 rprintf("\n");
	}
	return 0;
}
