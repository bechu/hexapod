// Example of converting Axon to USB to Serial Adapter

#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "servos.h"
#include "hardware.h"

//value to store compass angle
COMPASS_TYPE bearing;
//value to store servo angle
uint16_t angle;


// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	// Initialise the servo controller
	servoPWMInit(&bank1);

	//initialize compass
	compassInit(compass);

}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	compassRead(compass);//update compass value

	bearing = compass.compass.bearingDegrees;//store compass value

	angle=interpolate((int16_t)(bearing-180),-90,90,DRIVE_SPEED_MIN,DRIVE_SPEED_MAX);//convert bearing to servo angle

	rprintf("bearing=%d angle=%d\n",bearing-180,angle);//output data

	act_setSpeed(&servo_pointer,angle);//convert compass value to servo angle

	return 50000;
}
