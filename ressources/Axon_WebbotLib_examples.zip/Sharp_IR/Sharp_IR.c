// Example of converting Axon to USB to Serial Adapter


#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "hardware.h"
#include "a2d.h"

#define RPRINTF_FLOAT
#define RPRINTF_COMPLEX

//use for LED display
uint8_t led_value;
//additional math capabilities
#include <math.h>

// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	//initialize sensors
	distanceInit(sharp);
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	distanceRead(sharp);

	led_value=interpolate(sharp.distance.cm,0,30,0,9);//stretch value for LED display

	led_put_char(led_value);

	//output values via USB port
	distanceDump(sharp);
	//rprintf("\n%d", sharp.distance.cm);
	//rprintf("\nmine %d",(long int)(1384.4*pow(a2dConvert8bit(ADC_NUMBER_TO_CHANNEL(0)),-.9988)));
	rprintf("\n");

	return 200000;
}
