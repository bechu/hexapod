//define servos, sensors, and other stuff here
//this keeps hardware separate from other code - making it easy to share/port

//declare libraries
#include "Sensors/Distance/Sharp/GP2.h"


//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)38400
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte


//declare connected devices
Sharp_GP2D12 sharp = MAKE_Sharp_GP2D12(ADC0);//connect to ADC
//Sharp_GP2D120 sharp = MAKE_Sharp_GP2D12(ADC0);
//Sharp_GP2D15 sharp = MAKE_Sharp_GP2D12(ADC0);
//Sharp_GP2Y0A02YK sharp = MAKE_Sharp_GP2D12(ADC0);
//Sharp_GPY0A21YK sharp = MAKE_Sharp_GP2D12(ADC0);
