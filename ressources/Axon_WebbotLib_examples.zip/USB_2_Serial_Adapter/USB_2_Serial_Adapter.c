// Example of converting Axon to USB to Serial Adapter

#define RPRINTF_FLOAT

#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "hardware.h"


// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);//USB baud needs to be equal or higher, or a buffer overflow could occur
	uartInit(OTHER_UART, OTHER_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	led_put_char(1);
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	int tempbyte;
	
	tempbyte=uart0GetByte();//get a single character
	if (tempbyte!=-1)//if data recieved
		uart1SendByte(tempbyte);//send a byte
	tempbyte=uart1GetByte();//get a single character
	if (tempbyte!=-1)//if data recieved
		uart0SendByte(tempbyte);//send a byte
	
	return 0;
}
