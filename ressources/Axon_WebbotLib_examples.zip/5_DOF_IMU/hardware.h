//define servos, sensors, and other stuff here
//this keeps hardware separate from other code - making it easy to share/port

//declare libraries
#include "Sensors/Acceleration/AnalogDevices/ADXL335.h"
#include "Sensors/Gyro/InvenSense/IDG300.h"
//#include "Sensors/Gyro/InvenSense/IDG500.h"//the 300 is obsolete


//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)38400
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte

//define IMU variables
ACCEL_TYPE accel_X;
ACCEL_TYPE accel_Y;
ACCEL_TYPE accel_Z;
GYRO_TYPE gyro_X;
GYRO_TYPE gyro_Y;

//declare connected devices
ADXL335 accel=MAKE_ADXL335(ADC0,ADC1,ADC2);//requires 5V digital pin and 3V power
IDG300  gyro =MAKE_IDG300(ADC3,ADC4);//requires 5V digital pin and 3V power
//IDG500  gyro =MAKE_IDG500(ADC3,ADC4);//requires 5V digital pin and 3V power


//call this function to read all your sensors at once
void read_sensors(void)
	{
	//get values
	accelerometerRead(accel);
	gyroRead(gyro);

	//store values
	accel_X=accel.accelerometer.x_axis_mG;
	accel_Y=accel.accelerometer.y_axis_mG;
	accel_Z=accel.accelerometer.z_axis_mG;

	gyro_X=gyro.gyro.x_axis_degrees_per_second;
	gyro_Y=gyro.gyro.y_axis_degrees_per_second;
	}
