// Example of converting Axon to USB to Serial Adapter

#define RPRINTF_FLOAT

#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "hardware.h"

//use for LED display
uint8_t led_value;


// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	//initialize sensors
	accelerometerInit(accel);
	gyroInit(gyro);
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	read_sensors();//update sensor values

	led_value=interpolate(accel_X,-1000,1000,0,9);//stretch value for LED display

	led_put_char(led_value);
	//led_put_digit(2);

	//output values via USB port
	accelerometerDump(accel);
	rprintf("\n");
	gyroDump(gyro);
	rprintf("\n");

	return 200000;
}
