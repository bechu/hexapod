/*
Example of using PWM on Axon II

see datasheet to locate PWM pins:
http://www.societyofrobots.com/axon2/axon2_datasheet.shtml

please credit all code to societyofrobots.com
*/


//#define WIRELESS//if you want to use bluetooth and not USB, uncomment this line
#define USB//if you want to use bluetooth and not USB, uncomment this line



//#include "sys/axon.h"
#include "sys/axon2.h"
#include "rprintf.h"
#include "servos.h"
#include "pwm.h"
#include "motorPWM.h"


//make uart names more sane
#define USB_UART UART1
#define WIRELESS_UART UART2
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define USB_BAUD (BAUD_RATE)115200//230400
#define WIRELESS_BAUD (BAUD_RATE)38400


//declare motors
MOTOR left = MAKE_MOTOR(FALSE, L3,L4);
MOTOR right = MAKE_MOTOR(TRUE , L5,B5);
MOTOR_LIST motors[] = {&left,&right};
MOTOR_DRIVER motor_bank = MAKE_MOTOR_DRIVER(motors);


//use to track PWM duty in this example
uint8_t percentage=0;


//motor PWM
void motor_PWM(void)
	{
	act_setSpeed(&left,DRIVE_SPEED_MAX);
	act_setSpeed(&right,DRIVE_SPEED_MAX);
	}


//regular PWM example
void regular_PWM(void)
	{
	//boolean pwmInitHertz(const IOPin* pin, uint32_t hertz, DUTY_CYCLE duty,uint32_t* actualHertz)
	//note, only ONE frequency allowed per timer!
	pwmInitHertz(E3,1,50,null);
	pwmInitHertz(E4,1,20,null);
	
	//pwmSetDutyCycle(const IOPin* pin, DUTY_CYCLE duty)
	//Sets the PWM duty cycle on a pin that has already been initialised successfully.
	//pwmSetDutyCycle(E3,20);


	//boolean pwmDeciInitHertz(const IOPin* pin, uint32_t deciHertz,DUTY_CYCLE duty, uint32_t* actualDeciHertz)
	//Initialise PWM using the given frequency in DeciHertz - tenths of a Hertz - ie 1 = 0.1Hz, 10=1Hz etc.
	pwmInitDeciHertz(H6,1,50,null);
	//pwmInitDeciHertz(G5,1,50,null);
	}


// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);
	uartInit(WIRELESS_UART, WIRELESS_BAUD);

	// Set which uart is default during startup
	#ifdef USB
		rprintfInit(USB_ACTIVATE);
	#endif
	#ifdef WIRELESS
		rprintfInit(WIRELESS_ACTIVATE);
	#endif

	//initiate various PWM codes
	regular_PWM();
	motor_PWM();
	motorPWMInit(&motor_bank);

	rprintf("\nAxon initiated.\n");
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	//reset PWM if maxed out
	if(percentage==101)
		percentage=0;

	pwmSetDutyCycle(E3,percentage);//change PWM duty

	delay_ms(200);

	percentage++;


	return 0;
}

