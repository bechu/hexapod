//This demo shows how to display marquee text on an Axon II 

#include "sys/axon2.h"
#include "rprintf.h"
#include "hardware.h"



// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	led_off();
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n\n");

	// Set rprintf to go to the marquee
	rprintfInit( marqueeGetWriter(&marquee) );
	marqueeSetCharDelay(&marquee,600000);//set character delay time in us
	marqueeSetEndDelay(&marquee,0);//set as non-repeating

	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	rprintf("Buy an Axon\n");
	while(marqueeIsActive(&marquee));//delay until marquee is finished
	
	rprintf("0123456789\n");
	while(marqueeIsActive(&marquee));

	rprintf("abcdefghijklmnopqrstuvwxyz\n");
	while(marqueeIsActive(&marquee));

	//marqueeStop(&marquee);//stop a marquee from working
	
	return 2000;
}
