//define servos, sensors, and other stuff here
//this keeps hardware separate from other code - making it easy to share/port

//declare libraries
#include "Sensors/Compass/Devantech/CMPS03.h"


//UART defines (name your UART)
#define GPS_UART UART0
#define USB_UART UART1
#define WIRELESS_UART UART2
#define OTHER_UART UART3
//UART baud defines (change baud rate)
#define GPS_BAUD (BAUD_RATE)9600
#define USB_BAUD (BAUD_RATE)230400
#define WIRELESS_BAUD (BAUD_RATE)38400
#define OTHER_BAUD (BAUD_RATE)38400
//UART define which uart to use
#define GPS_ACTIVATE &uart0SendByte
#define USB_ACTIVATE &uart1SendByte
#define WIRELESS_ACTIVATE &uart2SendByte
#define OTHER_ACTIVATE &uart3SendByte


//declare connected devices
CMPS03 cmps03=MAKE_CMPS03(A0);//requires 5V digital pin


/////////////////////////////SERVOS///////////////////////////
SERVO servo_pointer = MAKE_SERVO(FALSE, L3, 1500, 500);

// Create the list - remember to place an & at the
// start of each servo name
SERVO_LIST servos[] = {&servo_pointer};

// Create a driver for the list of servos
SERVO_DRIVER bank1 = MAKE_SERVO_DRIVER(servos);
//////////////////////////////////////////////////////////////
