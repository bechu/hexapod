// Example of converting Axon to USB to Serial Adapter

#include "sys/axon2.h"
#include "led.h"
#include "rprintf.h"
#include "servos.h"
#include "hardware.h"

//value to store compass angle
COMPASS_TYPE bearing;


// This routine is called once only and allows you to do any initialisation
// Dont use any 'clock' functions here - use 'delay' functions instead
void appInitHardware(void){
	// Set up the hardware UART to xmit the results
	uartInit(USB_UART, USB_BAUD);

	// Set rprintf to go to output
	rprintfInit(USB_ACTIVATE);

	// Initialise the servo controller
	servoPWMInit(&bank1);

	//initialize compass
	compassInit(cmps03);
}

TICK_COUNT appInitSoftware(TICK_COUNT loopStart){
	rprintf("\nAxon initiated.\n");
	return 0;
}

// This routine is called repeatedly - its your main loop
TICK_COUNT appControl(LOOP_COUNT loopCount, TICK_COUNT loopStart){

	compassRead(cmps03);//update compass value

	rprintf("CMPS03=%d\n",cmps03.compass.bearingDegrees);//output data

	bearing = cmps03.compass.bearingDegrees;//store compass value

	act_setSpeed(&servo_pointer,(bearing-180)/2);//convert compass value to servo angle

	return 1000;
}
